import java.util.function.Function;

public class MapperClass {

	public Function<String, CharactersCount> getDistinctCharactersCount() 
	{
		return func-> {
			long count = func.chars()
            .distinct()
            .count();
			return new CharactersCount(func,(int)count);
	
};
}
}
