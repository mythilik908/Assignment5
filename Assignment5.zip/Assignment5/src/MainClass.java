import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


public class MainClass {
	
	 public static void main(String[] args) {
		 FilterClass c = new FilterClass();
		 MapperClass m = new MapperClass();
				 
		    Scanner scan = new Scanner(System.in);  // Create a Scanner object
		    System.out.println("Enter prefix");
		    
          List<String> inputs = Arrays.asList("aaryanna", "aayanna",
				 "airianna", "alassandra", "allanna", "allannah",
				 "allessandra", "allianna", "allyanna", "anastaisa",
				 "anastashia", "anastasia", "annabella", "annabelle",
				 "annebelle"); 
				 

		   inputs.stream().
		   filter(c.nameStartingWithPrefix(scan.next()))
		   .map(m.getDistinctCharactersCount())
		   .forEach(System.out::println);
		   scan.close();
		   
		   
		 
		 
	 }
	
}
