import java.util.function.Predicate;

public class FilterClass {

	
Predicate<String> nameStartingWithPrefix(String prefix) {
		
		return words-> words.startsWith(prefix);
		
	}
	
}
